const WIKTIONARY_API = 'https://en.wiktionary.org/w/api.php'

export async function lookupWord(word) {
  const url = `${WIKTIONARY_API}?action=parse&format=json&page=${encodeURIComponent(word)}&prop=text&origin=*`
  const res = await fetch(url)
  if (!res.ok) throw new Error('Network error')
  const json = await res.json()
  if (json.error) return null
  const html = json.parse?.text?.['*']
  if (!html) return null
  return parseGermanEntry(html, word)
}

function parseGermanEntry(html, word) {
  const doc = new DOMParser().parseFromString(html, 'text/html')
  const content = doc.querySelector('.mw-parser-output')
  if (!content) return null

  // Find the German h2 section
  const germanSection = findGermanSection(content)
  if (!germanSection) return null

  // Extract word type sections (Noun, Verb, Adjective, etc.)
  const posSections = extractPosSections(germanSection)
  if (posSections.length === 0) return null

  // Use the first/primary POS section
  const primary = posSections[0]

  const ipa = extractIPA(germanSection)
  const type = normalizeWordType(primary.type)
  const definitions = extractDefinitions(primary.nodes)
  const forms = extractForms(primary.nodes, type)

  return {
    word,
    type,
    ipa,
    definitions,
    forms,
    examples: [],
    allPos: posSections.map(s => s.type),
  }
}

function findGermanSection(content) {
  const children = Array.from(content.children)
  let inGerman = false
  const germanNodes = []

  for (const el of children) {
    if (el.tagName === 'H2') {
      const headline = el.querySelector('.mw-headline')
      const id = el.id || (headline?.id ?? '')
      const text = (headline?.textContent ?? el.textContent).trim()
      if (text === 'German' || id === 'German') {
        inGerman = true
        continue
      } else if (inGerman) {
        break // next language section — stop
      }
    }
    // Newer Wiktionary structure: <div class="mw-heading mw-heading2"><h2 id="German">German</h2>[edit]</div>
    // el.textContent includes the "[edit]" link text so we must read the h2 directly
    if (el.tagName === 'DIV' && el.classList.contains('mw-heading') && el.classList.contains('mw-heading2')) {
      const h2 = el.querySelector('h2')
      const id = h2?.id ?? ''
      const text = h2?.textContent.trim() ?? ''
      if (text === 'German' || id === 'German') {
        inGerman = true
        continue
      } else if (inGerman) {
        break
      }
    }
    if (inGerman) germanNodes.push(el)
  }

  return germanNodes.length > 0 ? germanNodes : null
}

function extractPosSections(nodes) {
  const sections = []
  let currentType = null
  let currentNodes = []

  const POS_TERMS = ['Noun', 'Verb', 'Adjective', 'Adverb', 'Pronoun', 'Preposition',
    'Conjunction', 'Article', 'Interjection', 'Numeral', 'Particle']

  for (const node of nodes) {
    const isH3 = node.tagName === 'H3'
    const isHeading3 = node.tagName === 'DIV' &&
      node.classList.contains('mw-heading') && node.classList.contains('mw-heading3')
    const isH4 = node.tagName === 'H4'
    const isHeading4 = node.tagName === 'DIV' &&
      node.classList.contains('mw-heading') && node.classList.contains('mw-heading4')

    if (isH3 || isHeading3 || isH4 || isHeading4) {
      const text = node.textContent.trim()
      const matched = POS_TERMS.find(pos => text.startsWith(pos))
      if (matched) {
        if (currentType) sections.push({ type: currentType, nodes: currentNodes })
        currentType = matched
        currentNodes = []
        continue
      }
    }
    if (currentType) currentNodes.push(node)
  }
  if (currentType) sections.push({ type: currentType, nodes: currentNodes })
  return sections
}

function extractIPA(nodes) {
  for (const node of nodes) {
    const ipaSpan = node.querySelector ? node.querySelector('span.IPA') : null
    if (ipaSpan) {
      const text = ipaSpan.textContent.trim()
      if (text) return text
    }
  }
  return null
}

function extractDefinitions(nodes) {
  const defs = []
  for (const node of nodes) {
    if (node.tagName === 'OL') {
      const items = node.querySelectorAll(':scope > li')
      for (const li of items) {
        // Get the text, stripping sub-lists and usage examples
        const clone = li.cloneNode(true)
        clone.querySelectorAll('dl, ul, ol').forEach(el => el.remove())
        clone.querySelectorAll('sup').forEach(el => el.remove())
        // Remove wiki-links formatting but keep text
        const text = cleanDefinitionText(clone.textContent.trim())
        if (text) {
          defs.push({ english: text })
        }
      }
    }
  }
  return defs.slice(0, 5) // cap at 5 definitions
}

function cleanDefinitionText(text) {
  return text
    .replace(/\s+/g, ' ')
    .replace(/^\s*[\d.]+\s*/, '') // remove leading numbers
    .trim()
    .slice(0, 200) // cap length
}

function extractForms(nodes, type) {
  // Find the inflection table in this section's nodes
  let table = null
  for (const node of nodes) {
    if (node.tagName === 'TABLE') {
      table = node
      break
    }
    if (node.querySelector) {
      table = node.querySelector('table')
      if (table) break
    }
  }

  if (!table) return null

  if (type === 'noun') return extractNounForms(table)
  if (type === 'verb') return extractVerbForms(table, nodes)
  if (type === 'adjective') return extractAdjectiveForms(table)
  return null
}

function extractNounForms(table) {
  const rows = Array.from(table.querySelectorAll('tr'))
  const result = {}

  // Try to find article/gender from the first row header
  const headerRow = rows[0]
  if (headerRow) {
    const abbrs = headerRow.querySelectorAll('abbr')
    for (const abbr of abbrs) {
      const title = (abbr.getAttribute('title') || '').toLowerCase()
      if (title.includes('neuter')) { result.article = 'das'; break }
      if (title.includes('masculine')) { result.article = 'der'; break }
      if (title.includes('feminine')) { result.article = 'die'; break }
    }
    // Also check cell text for der/die/das
    if (!result.article) {
      const text = headerRow.textContent
      if (/\bder\b/i.test(text)) result.article = 'der'
      else if (/\bdie\b/i.test(text)) result.article = 'die'
      else if (/\bdas\b/i.test(text)) result.article = 'das'
    }
  }

  // Build a row-indexed object
  const rowData = {}
  for (const row of rows) {
    const th = row.querySelector('th')
    if (!th) continue
    const label = th.textContent.trim().toLowerCase()
    const cells = Array.from(row.querySelectorAll('td'))
    const values = cells.map(td => td.textContent.trim())
    rowData[label] = values
  }

  // Extract nominative (article), genitive, plural
  const nomRow = Object.keys(rowData).find(k => k.includes('nominativ'))
  const genRow = Object.keys(rowData).find(k => k.includes('genitiv'))

  if (nomRow && rowData[nomRow]) {
    const nom = rowData[nomRow]
    // nom[0] = singular, nom[1] = plural
    if (nom[0] && !result.article) {
      const m = nom[0].match(/\b(der|die|das)\b/i)
      if (m) result.article = m[1].toLowerCase()
    }
    if (nom[1]) result.plural = nom[1]
  }
  if (genRow && rowData[genRow]) {
    const gen = rowData[genRow]
    if (gen[0]) result.genitive = gen[0]
  }

  // Fallback: extract plural from header columns
  if (!result.plural) {
    const headerCells = rows[0]?.querySelectorAll('th')
    if (headerCells) {
      for (const cell of headerCells) {
        if (cell.textContent.includes('Plural')) {
          // column index of plural
          // find nom row and get that column
          break
        }
      }
    }
  }

  return Object.keys(result).length > 0 ? result : null
}

function extractVerbForms(table, nodes) {
  const rows = Array.from(table.querySelectorAll('tr'))
  const conjugation = {}
  const tenses = {
    'Präsens': 'praesens',
    'Präteritum': 'praeteritum',
    'Perfekt': 'perfekt',
    'Futur': 'futur',
  }
  const persons = ['ich', 'du', 'er/sie/es', 'wir', 'ihr', 'sie']

  let currentTense = null
  const tenseMap = {}

  for (const row of rows) {
    const th = row.querySelector('th')
    const cells = Array.from(row.querySelectorAll('td'))

    if (th) {
      const label = th.textContent.trim()
      // Check if this is a tense header
      const tenseKey = Object.keys(tenses).find(t => label.startsWith(t))
      if (tenseKey) {
        currentTense = tenses[tenseKey]
        tenseMap[currentTense] = {}
        continue
      }
    }

    if (currentTense && cells.length >= 2) {
      const personCell = row.querySelector('th, td:first-child')
      const formCell = cells[cells.length - 1] || cells[0]
      if (personCell && formCell) {
        const person = personCell.textContent.trim().toLowerCase()
        const form = formCell.textContent.trim()
        if (form) {
          const personKey = persons.find(p => person.includes(p.split('/')[0]))
          if (personKey) {
            tenseMap[currentTense][personKey] = form
          }
        }
      }
    }
  }

  // Extract Partizip II and Imperativ — often in separate rows/section
  let partizipII = null
  let imperativ = null

  for (const row of rows) {
    const text = row.textContent
    if (/partizip\s*II/i.test(text)) {
      const td = row.querySelector('td')
      if (td) partizipII = td.textContent.trim()
    }
    if (/imperativ/i.test(text)) {
      const tds = row.querySelectorAll('td')
      if (tds.length > 0) imperativ = Array.from(tds).map(t => t.textContent.trim()).join(' / ')
    }
  }

  // Also check for partizip in non-table nodes
  if (!partizipII) {
    for (const node of nodes) {
      if (node.textContent?.includes('Partizip')) {
        const m = node.textContent.match(/Partizip\s*II[:\s]+([^\n,;]+)/i)
        if (m) partizipII = m[1].trim()
      }
    }
  }

  return {
    ...tenseMap,
    partizipII,
    imperativ,
  }
}

function extractAdjectiveForms(table) {
  const rows = Array.from(table.querySelectorAll('tr'))
  let comparative = null
  let superlative = null

  for (const row of rows) {
    const text = row.textContent.toLowerCase()
    const td = row.querySelector('td')
    if (!td) continue
    const value = td.textContent.trim()
    if (text.includes('komparativ') || text.includes('comparative')) comparative = value
    if (text.includes('superlativ') || text.includes('superlative')) superlative = value
  }

  // Try header row approach
  if (!comparative && !superlative) {
    const headerRow = rows[0]
    const dataRow = rows[1]
    if (headerRow && dataRow) {
      const headers = Array.from(headerRow.querySelectorAll('th')).map(th => th.textContent.trim().toLowerCase())
      const cells = Array.from(dataRow.querySelectorAll('td')).map(td => td.textContent.trim())
      const compIdx = headers.findIndex(h => h.includes('komparativ') || h.includes('comparative'))
      const supIdx = headers.findIndex(h => h.includes('superlativ') || h.includes('superlative'))
      if (compIdx >= 0) comparative = cells[compIdx]
      if (supIdx >= 0) superlative = cells[supIdx]
    }
  }

  if (!comparative && !superlative) return null
  return { comparative, superlative }
}

function normalizeWordType(raw) {
  const map = {
    'Noun': 'noun',
    'Verb': 'verb',
    'Adjective': 'adjective',
    'Adverb': 'adverb',
    'Pronoun': 'pronoun',
    'Preposition': 'preposition',
    'Conjunction': 'conjunction',
    'Article': 'article',
    'Interjection': 'interjection',
    'Numeral': 'numeral',
    'Particle': 'particle',
  }
  return map[raw] || raw.toLowerCase()
}
